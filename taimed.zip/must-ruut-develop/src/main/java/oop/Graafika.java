package oop;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


public class Graafika extends Application {


    @Override
    public void start(Stage lava) {
        Canvas lõuend = new Canvas();

        lõuend.setWidth(lava.getWidth());
        lõuend.setHeight(lava.getHeight());

        lava.setScene(esimene(lõuend, lava));
        lava.show();

    }

    //Abimeetod, mis loeb failist andmed sisse ja koostab nende põhjal taimede listi
    private List<Taim> loeTaimed(String failinimi, Text text) {

        List<Taim> taimed = new ArrayList<>();
        SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");

        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.MONTH, 1);
        Date lõppkuupäev = cal.getTime();

        try {
            DataInputStream dis = new DataInputStream(new FileInputStream(failinimi+".dat"));
            String nimi = dis.readUTF();
            while (nimi != null) {
                int kastmine = dis.readInt();
                String kkuupäev = dis.readUTF();
                int väetamine = dis.readInt();
                String vkuupäev = dis.readUTF();


                KastmisKuupäevad taimk = new KastmisKuupäevad(nimi, sdformat.parse(kkuupäev), "kastmine", kastmine);
                taimed.addAll(taimk.taimed(lõppkuupäev));
                VäetamisKuupäevad taimv = new VäetamisKuupäevad(nimi, sdformat.parse(vkuupäev), "väetamine", väetamine);
                taimed.addAll(taimv.taimed(lõppkuupäev));

                nimi = dis.readUTF();

            }
            dis.close();

        } catch (Exception e) {
            text.setText("Palun sisestage sobiv failinimi: \n");
        }
        Collections.sort(taimed);
        return taimed;
    }


    // Abimeetod, mis loob stseeni, kus küsitakse, kas fail on olemas
    private Scene esimene(Canvas lõuend, Stage lava) {
        BorderPane bp = new BorderPane();
        Text sissejuhatus = new Text("See programm on loodud selleks, et oma toataimede eest hoolitsemist lihtsamaks muuta. \nProgramm küsib sisendiks faili, kus on toataimede kohta andmed ning väljastab, mis kuupäevadel mida taimedega järgmise kuu jooksul teha tuleb. \nProgramm loob vajaliku faili ise. \nKas sul on selline fail olemas? \n");
        sissejuhatus.setWrappingWidth(lõuend.getWidth());
        bp.setTop(sissejuhatus);

        Button jah = new Button("Jah");
        Button ei = new Button("Ei");
        jah.setOnMouseClicked(event -> {
            lava.setScene(jah(lõuend, lava));
        });
        ei.setOnMouseClicked(event -> lava.setScene(ei(lõuend, lava)));
        bp.setLeft(jah);
        bp.setRight(ei);
        bp.getChildren().add(lõuend);

        Scene stseen = new Scene(bp, 960, 150);
        return stseen;

    }

    // Abimeetod, mis loob stseeni, mida näidatakse, kui eelmisel stseenil vajutatakse jah
    private Scene jah(Canvas lõuend, Stage lava) {

        BorderPane bp = new BorderPane();
        TextField tf = new TextField();
        Text tekst = new Text("Sisesta failinimi (nt \" taimed\"): \n");
        bp.setTop(tekst);

        tf.setOnKeyPressed(new EventHandler<KeyEvent>() {

            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode() == KeyCode.ENTER) {
                    if (tf.getText().trim().isEmpty() == false && tf.getText() != null) {
                        String a = tf.getText();
                        List<Taim> taimed = loeTaimed(a, tekst);
                        if (taimed.isEmpty()== false) {
                            lava.setScene(lisa(lõuend, a, taimed, lava));
                        }
                    }
                }
            }
        });
        bp.setLeft(tf);
        bp.getChildren().add(lõuend);
        Scene stseen = new Scene(bp);
        return stseen;
    }

    // Abimeetod, mis loob stseeni, mida näidatakse, kui eelmisel stseenil vajutatakse ei.
    private Scene ei(Canvas lõuend, Stage lava) {
        GridPane bp = new GridPane();
        Text mitu = new Text("Mitu taime sul on?\n");
        TextField tf = new TextField();
        Text fail = new Text("Sisestage failinimi, millesse soovite oma taimi salvestada (nt \"taimed\"): \n");
        TextField tfail = new TextField();


        tf.setOnKeyPressed(new EventHandler<KeyEvent>() {

            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode() == KeyCode.ENTER) {

                    if (tf.getText().trim().isEmpty() == false && tf.getText() != null) {
                        if (tfail.getText().trim().isEmpty() == false && tfail.getText() != null) {
                            int arv;
                            try {
                                arv = Integer.parseInt(tf.getText());
                                if (arv > 0) {
                                    String failinimi = tfail.getText();
                                    lava.setScene(küsiAndmed(arv, lõuend, lava, failinimi, new ArrayList<>()));
                                } else {
                                    mitu.setText("Palun sisestage sobiv arv!");
                                }
                            } catch (NumberFormatException e) {
                                mitu.setText("Palun sisestage täisarv!");
                            }
                        }
                    }
                }
            }
        });
        tfail.setOnKeyPressed(new EventHandler<KeyEvent>() {

            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode() == KeyCode.ENTER) {
                    if (tf.getText().trim().isEmpty() == false && tf.getText() != null) {
                        if (tfail.getText().trim().isEmpty() == false && tfail.getText() != null) {
                            int arv;
                            try {
                                arv = Integer.parseInt(tf.getText());
                                if (arv > 0) {
                                    String failinimi = tfail.getText();
                                    lava.setScene(küsiAndmed(arv, lõuend, lava, failinimi, new ArrayList<>()));
                                } else {
                                    mitu.setText("Palun sisestage sobiv arv!");
                                }
                            } catch (NumberFormatException e) {
                                mitu.setText("Palun sisestage täisarv!");
                            }
                        }
                    }
                }
            }
        });


        bp.add(mitu, 1, 1, 1, 1);
        bp.add(tf, 1, 2, 1, 1);
        bp.add(fail, 2, 1, 1, 1);
        bp.add(tfail, 2, 2, 1, 1);
        bp.setHgap(8);
        bp.setAlignment(Pos.CENTER);

        bp.getChildren().add(lõuend);

        Scene stseen = new Scene(bp);
        return stseen;
    }

    // Abmeetod, mis loob vajaliku ruudustiku, kuhu andmeid sisestada
    private Scene küsiAndmed(int arv, Canvas lõuend, Stage lava, String failinimi, List<Taim> taimed) {
        GridPane gp = new GridPane();
        Text kontroll = new Text();
        Text nimi = new Text("Taime nimi: ");
        Text kasmine = new Text("Kastmise sagedus päevades: ");
        Text väetamine = new Text("Väetamise sagedus kuudes: ");
        Text kkuupäev = new Text("Mingi kastmiskuupäev formaadis yyyy-MM-dd:");
        Text vkuupäev = new Text("Mingi väetamiskuupäev formaadis yyyy-MM-dd");
        gp.add(nimi, 1, 1, 1, 1);
        gp.add(kasmine, 2, 1, 1, 1);
        gp.add(kkuupäev, 3, 1, 1, 1);
        gp.add(väetamine, 4, 1, 1, 1);
        gp.add(vkuupäev, 5, 1, 1, 1);

        Map<List<Integer>, TextField> koordinaadid = new HashMap<>();


        for (int i = 0; i < arv; i++) {
            TextField nimit = new TextField();
            TextField kastmine = new TextField();
            TextField väetaminet = new TextField();
            TextField kkuupäevt = new TextField();
            TextField vkuupäevt = new TextField();
            gp.add(kontroll, 3, 0, 1, 1);
            gp.add(nimit, 1, i + 2, 1, 1);

            List<Integer> list = new ArrayList<>();
            list.add(1);
            list.add(i + 2);
            koordinaadid.put(list, nimit);
            gp.add(kastmine, 2, i + 2, 1, 1);

            List<Integer> listk = new ArrayList<>();
            listk.add(2);
            listk.add(i + 2);

            koordinaadid.put(listk, kastmine);
            gp.add(kkuupäevt, 3, i + 2, 1, 1);

            List<Integer> listkk = new ArrayList<>();
            listkk.add(3);
            listkk.add(i + 2);

            koordinaadid.put(listkk, kkuupäevt);
            gp.add(väetaminet, 4, i + 2, 1, 1);

            List<Integer> listv = new ArrayList<>();
            listv.add(4);
            listv.add(i + 2);

            koordinaadid.put(listv, väetaminet);
            gp.add(vkuupäevt, 5, i + 2, 1, 1);

            List<Integer> listvk = new ArrayList<>();
            listvk.add(5);
            listvk.add(i + 2);

            koordinaadid.put(listvk, vkuupäevt);
        }
        gp.setAlignment(Pos.CENTER);
        gp.setHgap(8);

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < gp.getRowCount() - 2; j++) {
                List<Integer> list = new ArrayList<>();
                list.add(i + 1);
                list.add(j + 2);

                TextField tf = koordinaadid.get(list);

                tf.setOnKeyPressed(new EventHandler<KeyEvent>() {
                    public void handle(KeyEvent keyEvent) {
                        if (keyEvent.getCode() == KeyCode.ENTER) {
                            SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
                            int a = 0;
                            for (int k = 0; k < 5; k++) {
                                for (int l = 0; l < gp.getRowCount() - 2; l++) {
                                    List<Integer> list2 = new ArrayList<>();
                                    list2.add(k + 1);
                                    list2.add(l + 2);


                                    if (koordinaadid.get(list2).getText().trim().isEmpty() || koordinaadid.get(list2).getText() == null) {
                                        a += 1;
                                    }
                                }
                            }
                            if (a == 0) {
                                try {
                                    for (int j = 0; j < gp.getRowCount() - 2; j++) {
                                        List<Integer> list2 = new ArrayList<>();
                                        List<Integer> list3 = new ArrayList<>();
                                        List<Integer> list4 = new ArrayList<>();
                                        List<Integer> list5 = new ArrayList<>();
                                        list2.add(2);
                                        list2.add(j + 2);
                                        list3.add(3);
                                        list3.add(j + 2);
                                        list4.add(4);
                                        list4.add(j + 2);
                                        list5.add(5);
                                        list5.add(j + 2);
                                        sdformat.parse(koordinaadid.get(list3).getText());
                                        sdformat.parse(koordinaadid.get(list5).getText());
                                        if (Integer.parseInt(koordinaadid.get(list2).getText()) < 1) {
                                            throw new NumberFormatException();
                                        }
                                        if (Integer.parseInt(koordinaadid.get(list4).getText()) < 1) {
                                            throw new NumberFormatException();
                                        }
                                    }
                                    try {
                                        DataOutputStream dos = new DataOutputStream(new FileOutputStream(failinimi + ".dat"));

                                        for (int j = 0; j < gp.getRowCount() - 2; j++) {
                                            List<Integer> list1 = new ArrayList<>();
                                            List<Integer> list2 = new ArrayList<>();
                                            List<Integer> list3 = new ArrayList<>();
                                            List<Integer> list4 = new ArrayList<>();
                                            List<Integer> list5 = new ArrayList<>();
                                            list1.add(1);
                                            list1.add(j + 2);
                                            list2.add(2);
                                            list2.add(j + 2);
                                            list3.add(3);
                                            list3.add(j + 2);
                                            list4.add(4);
                                            list4.add(j + 2);
                                            list5.add(5);
                                            list5.add(j + 2);
                                            dos.writeUTF(koordinaadid.get(list1).getText());
                                            dos.writeInt(Integer.parseInt(koordinaadid.get(list2).getText()));
                                            dos.writeUTF(koordinaadid.get(list3).getText());
                                            dos.writeInt(Integer.parseInt(koordinaadid.get(list4).getText()));
                                            dos.writeUTF(koordinaadid.get(list5).getText());
                                        }
                                        dos.close();
                                    } catch (Exception e) {
                                        throw new RuntimeException();
                                    }

                                    Text tekst = new Text();
                                    List<Taim> taimed2 = loeTaimed(failinimi, tekst);
                                    taimed.addAll(taimed2);
                                    Collections.sort(taimed);
                                    lava.setScene(stseen(lõuend, taimed));

                                } catch (NumberFormatException b) {
                                    kontroll.setText("Veendu, et kõik on korrektselt sisestatud!");
                                } catch (ParseException e) {
                                    kontroll.setText("Veendu, et kõik on korrektselt sisestatud!");
                                }

                            }
                        }
                    }
                });

            }
        }
        gp.getChildren().add(lõuend);
        Scene stseen = new Scene(gp);
        return stseen;
    }

    // Abimeetod, mis loob stseeni, kus kuvatakse, mida taimedega teha tuleb
    private Scene stseen(Canvas lõuend, List<Taim> taimed) {
        BorderPane bp = new BorderPane();

        StringBuilder sb = new StringBuilder();
        sb.append(taimed.get(0).getKuupäev().getDate() + "." + (int) (taimed.get(0).getKuupäev().getMonth() + 1) + "." + (int) (taimed.get(0).getKuupäev().getYear() + 1900) + ": \n");
        sb.append(taimed.get(0).getNimi() + " " + taimed.get(0).getTegevus() + "\n");

        for (int i = 1; i < taimed.size(); i++) {
            if (taimed.get(i).getKuupäev().getYear() == taimed.get(i - 1).getKuupäev().getYear()) {
                if (taimed.get(i).getKuupäev().getMonth() == taimed.get(i - 1).getKuupäev().getMonth()) {
                    if (taimed.get(i).getKuupäev().getDate() == taimed.get(i - 1).getKuupäev().getDate()) {
                        sb.append(taimed.get(i).getNimi() + " " + taimed.get(i).getTegevus() + "\n");
                    } else {
                        sb.append(taimed.get(i).getKuupäev().getDate() + "." + (int) (taimed.get(i).getKuupäev().getMonth() + 1) + "." + (int) (taimed.get(i).getKuupäev().getYear() + 1900) + ": \n");
                        sb.append(taimed.get(i).getNimi() + " " + taimed.get(i).getTegevus() + "\n");

                    }
                } else {
                    sb.append(taimed.get(i).getKuupäev().getDate() + "." + (int) (taimed.get(i).getKuupäev().getMonth() + 1) + "." + (int) (taimed.get(i).getKuupäev().getYear() + 1900) + ": \n");
                    sb.append(taimed.get(i).getNimi() + " " + taimed.get(i).getTegevus() + "\n");

                }
            } else {
                sb.append(taimed.get(i).getKuupäev().getDate() + "." + (int) (taimed.get(i).getKuupäev().getMonth() + 1) + "." + (int) (taimed.get(i).getKuupäev().getYear() + 1900) + ": \n");
                sb.append(taimed.get(i).getNimi() + " " + taimed.get(i).getTegevus() + "\n");

            }
        }

        Text tegevused = new Text("Järgmise kuu jooksul tehtavad tegevused: \n" + sb);

        ScrollPane scroll = new ScrollPane();
        scroll.setContent(tegevused);
        scroll.pannableProperty().set(true);
        scroll.setFitToHeight(true);
        scroll.setFitToWidth(true);
        scroll.vbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.ALWAYS);
        scroll.hbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.ALWAYS);

        bp.setCenter(scroll);

        bp.getChildren().add(lõuend);

        Scene stseen = new Scene(bp, 250, 500);
        return stseen;
    }

    // Abimeetod, mis küsib, kas faili olemasolul soovitakse andmeid ka teiste taimede kohta
    private Scene lisa(Canvas lõuend, String fail, List<Taim> taimed, Stage lava){
        BorderPane bp = new BorderPane();
        Text sissejuhatus = new Text("Kas soovid infot veel mõne taime kohta? \n");
        sissejuhatus.setWrappingWidth(lõuend.getWidth());
        bp.setTop(sissejuhatus);

        Button jah = new Button("Jah");
        Button ei = new Button("Ei");
        jah.setOnMouseClicked(event -> {
            lava.setScene(jah2(lõuend, fail, taimed, lava));
        });
        ei.setOnMouseClicked(event -> lava.setScene(stseen(lõuend, taimed)));
        bp.setLeft(jah);
        bp.setRight(ei);
        bp.getChildren().add(lõuend);

        Scene stseen = new Scene(bp, 250, 75);
        return stseen;

    }

    // Abimeetod, mis loob stseeni, kus meetodis lisa() vastati jah
    private Scene jah2(Canvas lõuend, String fail, List<Taim> taimed, Stage lava){
        GridPane bp = new GridPane();
        Text mitu = new Text("Mitu taime soovid lisada? \n");
        TextField tf = new TextField();
        Text fail2 = new Text("Sisestage failinimi, millesse soovite uued taimed salvestada (nt \"taimed\"): \n");
        TextField tfail = new TextField();


        tf.setOnKeyPressed(new EventHandler<KeyEvent>() {

            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode() == KeyCode.ENTER) {

                    if (tf.getText().trim().isEmpty() == false && tf.getText() != null) {
                        if (tfail.getText().trim().isEmpty() == false && tfail.getText() != null) {
                            if(tfail.getText().equals(fail)) {
                                fail2.setText("Failinimi ei tohi olla sama, mis sisendfaili nimi!");

                            }else{
                                int arv;
                                try {
                                    arv = Integer.parseInt(tf.getText());
                                    if (arv > 0) {
                                        String failinimi = tfail.getText();
                                        lava.setScene(küsiAndmed(arv, lõuend, lava, failinimi, taimed));
                                    } else {
                                        mitu.setText("Palun sisestage sobiv arv!");
                                    }
                                } catch (NumberFormatException e) {
                                    mitu.setText("Palun sisestage täisarv!");
                                }
                            }
                        }
                    }
                }
            }
        });
        tfail.setOnKeyPressed(new EventHandler<KeyEvent>() {

            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode() == KeyCode.ENTER) {
                    if (tf.getText().trim().isEmpty() == false && tf.getText() != null) {
                        if (tfail.getText().trim().isEmpty() == false && tfail.getText() != null) {
                            if(tfail.getText().equals(fail)) {
                                fail2.setText("Failinimi ei tohi olla sama, mis sisendfaili nimi!");
                            }
                            else {
                                int arv;
                                try {
                                    arv = Integer.parseInt(tf.getText());
                                    if (arv > 0) {
                                        String failinimi = tfail.getText();
                                        lava.setScene(küsiAndmed(arv, lõuend, lava, failinimi, taimed));
                                    } else {
                                        mitu.setText("Palun sisestage sobiv arv!");
                                    }
                                } catch (NumberFormatException e) {
                                    mitu.setText("Palun sisestage täisarv!");
                                }
                            }
                        }
                    }
                }
            }
        });


        bp.add(mitu, 1, 1, 1, 1);
        bp.add(tf, 1, 2, 1, 1);
        bp.add(fail2, 2, 1, 1, 1);
        bp.add(tfail, 2, 2, 1, 1);
        bp.setHgap(8);
        bp.setAlignment(Pos.CENTER);

        bp.getChildren().add(lõuend);

        Scene stseen = new Scene(bp);
        return stseen;

    }


    // main meetod paneb programmi tööle
    public static void main(String[] args) {
        launch(args);
    }
}
