package oop;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class VäetamisKuupäevad extends Taim {
    //Klassi Taim alamklass

    private int sagedus;

    public VäetamisKuupäevad(String nimi, Date kuupäev, String tegevus, int sagedus) {
        super(nimi, kuupäev, tegevus);
        this.sagedus = sagedus;
    }

    //Luuakse kuupäevade list, kus on kõik kuupäevad alates järgmisest kasutuskorrast kuni lõppkuupäevani (vahe on sagedus kuud)
    public List<Date> kuupäevad(Date lõppkuupäev) {
        List<Date> päevad = new ArrayList<>();
        Date kuupäev = super.getKuupäev();
        Calendar cal = Calendar.getInstance();

        while (kuupäev.compareTo(lõppkuupäev) < 0) {
            päevad.add(kuupäev);
            cal.setTime(kuupäev);
            cal.add(Calendar.MONTH, sagedus);
            kuupäev = cal.getTime();
        }

        return päevad;
    }

    //Luuakse taimede list, kus on iga eelmise meetodi abil loodud kuupäevale vastav klassi Taim isend
    public List<Taim> taimed(Date lõppkuupäev) {
        Calendar tänac = Calendar.getInstance();
        tänac.add(Calendar.DAY_OF_MONTH, -1);
        Date täna = tänac.getTime();
        List<Taim> taimed = new ArrayList<>();
        for (int i = 0; i < kuupäevad(lõppkuupäev).size(); i++) {
            if (kuupäevad(lõppkuupäev).get(i).compareTo(täna) > 0) {
                Taim taim = new Taim(super.getNimi(), kuupäevad(lõppkuupäev).get(i), super.getTegevus());
                taimed.add(taim);
            }
        }
        return taimed;
    }

}
