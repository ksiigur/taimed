package oop;

import java.util.Date;

public class Taim implements Comparable<Taim> {

    private String nimi;
    private Date kuupäev;
    private String tegevus;

    public Taim(String nimi, Date kuupäev, String tegevus) {
        this.nimi = nimi;
        this.kuupäev = kuupäev;
        this.tegevus = tegevus;
    }

    public Date getKuupäev() {
        return kuupäev;
    }

    public String getNimi() {
        return nimi;
    }

    public String getTegevus() {
        return tegevus;
    }

    //Selle abil saab taimed kuupäevade järgi järjestada
    public int compareTo(Taim võrreldav) {

        if (kuupäev.compareTo(võrreldav.getKuupäev()) > 0)
            return 1;
        if (kuupäev.compareTo(võrreldav.getKuupäev()) < 0)
            return -1;
        return 0;
    }
}


